package com.torryharris.employee.crud.util;

public class QueryNames {
  public static final String GET_ALL_EMPLOYEES = "GET_ALL_EMPLOYEES";
  public static final String GET_BY_ID = "GET_BY_ID";
  public static final String INSERT_EMPLOYEE = "INSERT_EMPLOYEE";
  public static final String UPDATE_EMPLOYEE = "UPDATE_EMPLOYEE";
  public static final String DELETE_EMPLOYEE = "DELETE_EMPLOYEE";
}
